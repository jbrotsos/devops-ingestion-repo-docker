#!/bin/sh

basedir=$(dirname "$0")

case `uname` in
    *CYGWIN*) basedir=$(cygpath -w "$basedir");;
esac

apt-get $@

exit $?
